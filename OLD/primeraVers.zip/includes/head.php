<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tei Sushi | <? echo $title?></title>
    <link rel="shortcut icon" href="/img/favicon.png" />
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Libre+Caslon+Display&amp;family=Pinyon+Script&amp;display=swap">
    <link rel="stylesheet" href="/css/plugins.css" />
    <link rel="stylesheet" href="/css/style.css" />
</head>