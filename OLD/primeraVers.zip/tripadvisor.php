<?php
header('Location: https://www.tripadvisor.com.mx/UserReviewEdit-g152516-d23891685-Tei_Sushi-San_Jose_del_Cabo_Los_Cabos_Baja_California.html');
exit;
?>